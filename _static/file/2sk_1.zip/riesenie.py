# skuska variant A
# student: Janko Hraško
# datum: 9.6.2026

inf = float('inf')

class Graph:
    class Vertex:
        def __init__(self, x, y):
            self.xy = self.x, self.y = x, y
            self.d = None

        def __repr__(self):
            return f'Vertex{self.xy}'

    def __init__(self, filename):
        self.vertices = []                         # jednorozmerné pole vrcholov typu Vertex
        ...

    def get_vertex(self, x, y):                    # vráti príslušný Vertex
        ...

    def get_weight(self, vertex1, vertex2):        # vráti váhu hrany
        ...

    def get_distance(self, vertex1, vertex2):      # vráti najkratšiu vzdialenosť (súčet váh)
        ...

    def get_path(self, vertex1, vertex2):          # vráti postupnosť vrcholov z vertex1 do vertex2
        ...

if __name__ == '__main__':
    g = Graph('subor1.txt')
    v1 = g.get_vertex(66, 5)
    v2 = g.get_vertex(68, 93)
    print(f'{g.get_weight(v1, v2) = }')
    print(f'{g.get_distance(v1, v2) = }')
    print(f'{g.get_path(v1, v2) = }')
