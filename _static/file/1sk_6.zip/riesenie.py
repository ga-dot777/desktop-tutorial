# 6. skuska: colorsok
# student: Janko Hraško
# datum: 13.2.2026

class Colorsok:
    def __init__(self, meno_suboru):
        ...

    def __repr__(self):
        return ''

    @property
    def kvadre(self):
        ...

    @property
    def pri_sebe(self):
        ...

    def posun(self, prikazy):
        ...

if __name__ == '__main__':
    c = Colorsok('subor1.txt')
    print(c)
    print(f'{c.kvadre = }')
    print(f'{c.pri_sebe = }')
    print(f'{c.posun('lhp') = }')
    print(c)
    print(f'{c.pri_sebe = }')
    print(f'{c.posun('d') = }')
    print(f'{c.kvadre['b'] = }')
    print(f'{c.pri_sebe = }')
