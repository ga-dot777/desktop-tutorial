# 5. skuska: robot emil
# student: Janko Hraško
# datum: 4.2.2026

class RobotEmil:
    def __init__(self, meno_suboru):
        ...

    def daj_robot(self):
        ...

    def zmen_robot(self, pozicia):
        ...

    robot = property(daj_robot, zmen_robot)

    def __repr__(self):
        return ''

    def rob(self, prikazy):
        ...

    @property
    def postupne(self):
        ...

if __name__ == '__main__':
    e = RobotEmil('subor1.txt')
    e.robot = 0, 1
    print(e)
    print(f'{e.robot = }')
    print(f'{e.rob('zvjv') = }')
    print(e)
    print(f'{e.postupne = }')
