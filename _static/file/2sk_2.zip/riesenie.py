# skuska variant B
# student: Janko Hraško
# datum: 10.6.2026

class Kocurkovo:
    def __init__(self, meno_suboru):
        ...

    @property
    def pozemky(self):              # vráti množinu mien pozemkov
        ...

    @property
    def vrcholy(self):              # vráti množinu mien vrcholov
        ...

    def __getitem__(self, index):   # index je dvojica vrcholov
        ...

    def ries(self, v1, ciel):       # vráti množinu n-tíc s menami vrcholov
        ...

if __name__ == '__main__':
    g = Kocurkovo('subor1.txt')
    print(f'{g.pozemky = }')
    print(f'{g.vrcholy = }')
    for v1, v2 in ('a3', 'b2'), ('a2', 'a1'), ('b1', 'a1'):
        print(f'g[{v1!r}, {v2!r}] = {g[v1, v2]}')
    print(f'{g.ries('b1', {'p2', 'p4'}) = }')
