# skuska variant C
# student: Janko Hraško
# datum: 25.6.2026

class PodmorskaStanica:
    def __init__(self, meno_suboru):
        self.mena = []
        self.tab = []
        ...

    def start(self, modul):
        ...
        return ...

    def zablokuj(self, *moduly):
        ...
        return ...

    def __getitem__(self, modul):
        ...
        return ...

if __name__ == '__main__':
    st = PodmorskaStanica('subor1.txt')
    print(f'{st.mena = }')
    print(f'{st.tab[st.mena.index('e15')][st.mena.index('d18')] = }')
    print(f'{st.tab[st.mena.index('e15')][st.mena.index('c23')] = }')
    print(f'{st['c23'] = }')
    print(f'{st.start('a12') = }')
    print(f'{st.zablokuj('c23') = }; {st.start('a12') = }')
    print(f'{st.zablokuj('c23') = }; {st.start('d18') = }')
    print(f'{st.zablokuj('a12') = }; {st.start('d18') = }')
    print(f'{st.zablokuj('b15') = }; {st.start('d18') = }')
    print(f'{st.zablokuj('b15', 'e15') = }; {st.start('a12') = }')
    print(f'{st.zablokuj('d18') = }; {st.start('d18') = }')
