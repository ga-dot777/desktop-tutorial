# 4. skuska: light bot
# student: Janko Hraško
# datum: 3.2.2026

class LightBot:
    def __init__(self, meno_suboru):
        ...

    @property
    def robot(self):
        ...

    @robot.setter
    def robot(self, pozicia_robota):
        ...

    def __repr__(self):
        return ''

    def rob(self, prikazy):
        ...

    @property
    def lampy(self):
        ...

if __name__ == '__main__':
    r = LightBot('subor1.txt')
    print(f'{r.lampy = }')
    r.robot = 3, 4, 2
    print(r)
    print(f'{r.robot = }')
    print(f'{r.rob('kpssszlkzklkk') = }')
    print(f'{r.robot = }')
    print(r)
    print(f'{r.lampy = }')
