# skuska variant D
# student: Janko Hraško
# datum: 29.6.2026

inf = float('inf')

class Graph:
    def __init__(self, filename):
        self.vertices = {}
        self.d = {}
        ...

    def incident_edges(self, name1):   # generátor, vracia dvojice meno a vahu
        ...

    def dijkstra(self, name1):
        ...

    def get_path(self, name1, name2):  # generátor, vracia cestu
        ...

if __name__ == '__main__':
    g = Graph('subor1.txt')
    g.dijkstra('0')
    print('d = ', *(g.d[name] for name in sorted(g.vertices)))
    print(*g.get_path('0', '8'))
    print(*g.get_path('0', '5'))
    print(*g.get_path('0', '0'))
