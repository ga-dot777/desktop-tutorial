# 3. skuska: q*bert
# student: Janko Hraško
# datum: 27.1.2026

class Q_Bert:
    def __init__(self, meno_suboru):
        ...

    def __repr__(self):
        return ''

    def start(self, r, s):
        ...

    def pohyb(self, smer):
        ...

    @property
    def zlte(self):
        ...

    @property
    def modre(self):
        ...


if __name__ == '__main__':
    q = Q_Bert('subor1.txt')
    print(f'{q.start(1, 5) = }')
    print(q)
    print(f'{q.zlte = }')
    print(f'{q.modre = }')
    print(f'{q.pohyb(4) = }')
    print(f'{q.pohyb(4422334) = }')
    print(q)
    print(f'{q.zlte = }')
    print(f'{q.modre = }')
